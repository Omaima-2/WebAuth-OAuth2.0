import {
    startRegistration,
    startAuthentication,
  } from 'https://cdn.skypack.dev/@simplewebauthn/browser';
  
  // sign in 
  export async function register() {

    const username = document.getElementById('username').value;

    // send to the server 
    let optionsRes = await fetch('/register/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username }),
      });

      let options = await optionsRes.json();
      if (options.error) {
      return alert(options.error);
      }

      let attestation = await startRegistration(options); 

      // not on the slide ..?
      let verificationRes = await fetch('/register/finish', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username,
          attestationResponse: attestation,
        }),
      });

      let verificationResult = await verificationRes.json();
      alert(`Registration ${verificationResult ? 'successful' : 'failed'}`);
  }

// Log in 
  export async function login() {

    const username = document.getElementById('username').value;

    let optionsRes = await fetch('/login/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username }),
      });

    let options = await optionsRes.json();
    if (options.error) {
    return alert(options.error);
    }

    console.log(options); // is it important? 

    let assertion = await startAuthentication(options);
    
    let verificationRes = await fetch('/login/finish', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      username,
      assertionResponse: assertion,
    }),
  });  

     let verificationResult = await verificationRes.json();
     alert(`Login ${verificationResult ? 'successful' : 'failed'}`);
  }

  // Check if the login button exists before binding the event listener
const loginButton = document.getElementById('loginBtn');
if (loginButton) {
  loginButton.addEventListener('click', login);
}

// Check if the register button exists before binding the event listener
const registerButton = document.getElementById('registerBtn');
if (registerButton) {
  registerButton.addEventListener('click', register);
}



document.getElementById('continue-github-btn').addEventListener('click', () => {
  window.location.href = '/auth/github';
});

document.getElementById('continue-google-btn').addEventListener('click', () => {
    window.location.href = '/auth/google';
});